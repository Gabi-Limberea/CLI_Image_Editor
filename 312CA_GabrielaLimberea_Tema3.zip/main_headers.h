// Copyright 2021 - 2022: Limberea Gabriela 312CA
#pragma once

#include "macros.h"
#include "load_image.h"
#include "select.h"
#include "save_image.h"
#include "rotate.h"
#include "crop.h"
#include "apply.h"
