// Copyright 2021 - 2022: Limberea Gabriela 312CA

#ifndef __main__headers__
#define __main__headers__

#include "macros.h"
#include "load_image.h"
#include "select.h"
#include "save_image.h"
#include "rotate.h"
#include "crop.h"
#include "apply.h"

#endif
